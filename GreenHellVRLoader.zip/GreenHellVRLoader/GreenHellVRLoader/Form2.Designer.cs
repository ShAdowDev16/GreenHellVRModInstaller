﻿namespace GreenHellVRLoader
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges43 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges44 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges31 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges32 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges33 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges34 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges35 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges36 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges37 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges38 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges39 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges40 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges41 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges42 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges29 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges30 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges27 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges28 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges25 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges26 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2AnimateWindow1 = new Guna.UI2.WinForms.Guna2AnimateWindow(components);
            guna2BorderlessForm1 = new Guna.UI2.WinForms.Guna2BorderlessForm(components);
            guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            BackButton = new Guna.UI2.WinForms.Guna2Button();
            guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            guna2ControlBox4 = new Guna.UI2.WinForms.Guna2ControlBox();
            guna2ControlBox3 = new Guna.UI2.WinForms.Guna2ControlBox();
            guna2ControlBox2 = new Guna.UI2.WinForms.Guna2ControlBox();
            guna2ControlBox1 = new Guna.UI2.WinForms.Guna2ControlBox();
            guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            InstallBepinexButton = new Guna.UI2.WinForms.Guna2Button();
            guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button3 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button4 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button5 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button6 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button7 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button8 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button9 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button10 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button11 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button12 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button13 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button14 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button15 = new Guna.UI2.WinForms.Guna2Button();
            guna2Panel1.SuspendLayout();
            SuspendLayout();
            // 
            // guna2BorderlessForm1
            // 
            guna2BorderlessForm1.ContainerControl = this;
            guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6D;
            guna2BorderlessForm1.TransparentWhileDrag = true;
            // 
            // guna2Panel1
            // 
            guna2Panel1.BackColor = SystemColors.ControlDark;
            guna2Panel1.Controls.Add(BackButton);
            guna2Panel1.Controls.Add(guna2Panel2);
            guna2Panel1.Controls.Add(guna2ControlBox4);
            guna2Panel1.Controls.Add(guna2ControlBox3);
            guna2Panel1.Controls.Add(guna2ControlBox2);
            guna2Panel1.Controls.Add(guna2ControlBox1);
            guna2Panel1.Controls.Add(guna2HtmlLabel1);
            guna2Panel1.CustomizableEdges = customizableEdges43;
            guna2Panel1.Location = new Point(-7, 1);
            guna2Panel1.Name = "guna2Panel1";
            guna2Panel1.ShadowDecoration.CustomizableEdges = customizableEdges44;
            guna2Panel1.Size = new Size(790, 73);
            guna2Panel1.TabIndex = 2;
            // 
            // BackButton
            // 
            BackButton.CustomizableEdges = customizableEdges31;
            BackButton.DisabledState.BorderColor = Color.DarkGray;
            BackButton.DisabledState.CustomBorderColor = Color.DarkGray;
            BackButton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            BackButton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            BackButton.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            BackButton.ForeColor = Color.White;
            BackButton.Location = new Point(344, 11);
            BackButton.Name = "BackButton";
            BackButton.ShadowDecoration.CustomizableEdges = customizableEdges32;
            BackButton.Size = new Size(81, 39);
            BackButton.TabIndex = 10;
            BackButton.Text = "Back";
            BackButton.Click += BackButton_Click;
            // 
            // guna2Panel2
            // 
            guna2Panel2.CustomizableEdges = customizableEdges33;
            guna2Panel2.Location = new Point(172, 70);
            guna2Panel2.Name = "guna2Panel2";
            guna2Panel2.ShadowDecoration.CustomizableEdges = customizableEdges34;
            guna2Panel2.Size = new Size(0, 0);
            guna2Panel2.TabIndex = 9;
            // 
            // guna2ControlBox4
            // 
            guna2ControlBox4.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            guna2ControlBox4.CustomizableEdges = customizableEdges35;
            guna2ControlBox4.FillColor = Color.FromArgb(139, 152, 166);
            guna2ControlBox4.IconColor = Color.White;
            guna2ControlBox4.Location = new Point(721, 14);
            guna2ControlBox4.Name = "guna2ControlBox4";
            guna2ControlBox4.ShadowDecoration.CustomizableEdges = customizableEdges36;
            guna2ControlBox4.Size = new Size(56, 36);
            guna2ControlBox4.TabIndex = 7;
            // 
            // guna2ControlBox3
            // 
            guna2ControlBox3.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            guna2ControlBox3.ControlBoxType = Guna.UI2.WinForms.Enums.ControlBoxType.MinimizeBox;
            guna2ControlBox3.CustomizableEdges = customizableEdges37;
            guna2ControlBox3.FillColor = Color.FromArgb(139, 152, 166);
            guna2ControlBox3.IconColor = Color.White;
            guna2ControlBox3.Location = new Point(634, 14);
            guna2ControlBox3.Name = "guna2ControlBox3";
            guna2ControlBox3.ShadowDecoration.CustomizableEdges = customizableEdges38;
            guna2ControlBox3.Size = new Size(56, 36);
            guna2ControlBox3.TabIndex = 6;
            // 
            // guna2ControlBox2
            // 
            guna2ControlBox2.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            guna2ControlBox2.ControlBoxType = Guna.UI2.WinForms.Enums.ControlBoxType.MinimizeBox;
            guna2ControlBox2.CustomizableEdges = customizableEdges39;
            guna2ControlBox2.FillColor = Color.FromArgb(139, 152, 166);
            guna2ControlBox2.IconColor = Color.White;
            guna2ControlBox2.Location = new Point(1250, 3);
            guna2ControlBox2.Name = "guna2ControlBox2";
            guna2ControlBox2.ShadowDecoration.CustomizableEdges = customizableEdges40;
            guna2ControlBox2.Size = new Size(56, 36);
            guna2ControlBox2.TabIndex = 2;
            // 
            // guna2ControlBox1
            // 
            guna2ControlBox1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            guna2ControlBox1.CustomizableEdges = customizableEdges41;
            guna2ControlBox1.FillColor = Color.FromArgb(139, 152, 166);
            guna2ControlBox1.IconColor = Color.White;
            guna2ControlBox1.Location = new Point(1321, 3);
            guna2ControlBox1.Name = "guna2ControlBox1";
            guna2ControlBox1.ShadowDecoration.CustomizableEdges = customizableEdges42;
            guna2ControlBox1.Size = new Size(56, 36);
            guna2ControlBox1.TabIndex = 1;
            // 
            // guna2HtmlLabel1
            // 
            guna2HtmlLabel1.BackColor = Color.Transparent;
            guna2HtmlLabel1.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            guna2HtmlLabel1.Location = new Point(11, 3);
            guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            guna2HtmlLabel1.Size = new Size(311, 47);
            guna2HtmlLabel1.TabIndex = 0;
            guna2HtmlLabel1.Text = "GreenHellVR Modder";
            guna2HtmlLabel1.Click += guna2HtmlLabel1_Click;
            // 
            // InstallBepinexButton
            // 
            InstallBepinexButton.BorderRadius = 10;
            InstallBepinexButton.CustomizableEdges = customizableEdges29;
            InstallBepinexButton.DisabledState.BorderColor = Color.DarkGray;
            InstallBepinexButton.DisabledState.CustomBorderColor = Color.DarkGray;
            InstallBepinexButton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            InstallBepinexButton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            InstallBepinexButton.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            InstallBepinexButton.ForeColor = Color.White;
            InstallBepinexButton.Location = new Point(24, 80);
            InstallBepinexButton.Name = "InstallBepinexButton";
            InstallBepinexButton.ShadowDecoration.CustomizableEdges = customizableEdges30;
            InstallBepinexButton.Size = new Size(225, 56);
            InstallBepinexButton.TabIndex = 10;
            InstallBepinexButton.Text = "Install Bepinex (required)";
            InstallBepinexButton.Click += guna2Button1_Click;
            // 
            // guna2Button2
            // 
            guna2Button2.BorderRadius = 10;
            guna2Button2.CustomizableEdges = customizableEdges27;
            guna2Button2.DisabledState.BorderColor = Color.DarkGray;
            guna2Button2.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button2.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button2.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button2.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button2.ForeColor = Color.White;
            guna2Button2.Location = new Point(24, 142);
            guna2Button2.Name = "guna2Button2";
            guna2Button2.ShadowDecoration.CustomizableEdges = customizableEdges28;
            guna2Button2.Size = new Size(225, 56);
            guna2Button2.TabIndex = 11;
            guna2Button2.Text = "Inject (MOD NAME)";
            guna2Button2.Click += guna2Button2_Click_1;
            // 
            // guna2Button3
            // 
            guna2Button3.BorderRadius = 10;
            guna2Button3.CustomizableEdges = customizableEdges25;
            guna2Button3.DisabledState.BorderColor = Color.DarkGray;
            guna2Button3.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button3.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button3.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button3.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button3.ForeColor = Color.White;
            guna2Button3.Location = new Point(24, 204);
            guna2Button3.Name = "guna2Button3";
            guna2Button3.ShadowDecoration.CustomizableEdges = customizableEdges26;
            guna2Button3.Size = new Size(225, 56);
            guna2Button3.TabIndex = 12;
            guna2Button3.Text = "Inject (MOD NAME)";
            // 
            // guna2Button4
            // 
            guna2Button4.BorderRadius = 10;
            guna2Button4.CustomizableEdges = customizableEdges23;
            guna2Button4.DisabledState.BorderColor = Color.DarkGray;
            guna2Button4.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button4.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button4.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button4.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button4.ForeColor = Color.White;
            guna2Button4.Location = new Point(24, 266);
            guna2Button4.Name = "guna2Button4";
            guna2Button4.ShadowDecoration.CustomizableEdges = customizableEdges24;
            guna2Button4.Size = new Size(225, 56);
            guna2Button4.TabIndex = 13;
            guna2Button4.Text = "Inject (MOD NAME)";
            // 
            // guna2Button5
            // 
            guna2Button5.BorderRadius = 10;
            guna2Button5.CustomizableEdges = customizableEdges21;
            guna2Button5.DisabledState.BorderColor = Color.DarkGray;
            guna2Button5.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button5.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button5.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button5.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button5.ForeColor = Color.White;
            guna2Button5.Location = new Point(24, 328);
            guna2Button5.Name = "guna2Button5";
            guna2Button5.ShadowDecoration.CustomizableEdges = customizableEdges22;
            guna2Button5.Size = new Size(225, 56);
            guna2Button5.TabIndex = 14;
            guna2Button5.Text = "Inject (MOD NAME)";
            // 
            // guna2Button6
            // 
            guna2Button6.BorderRadius = 10;
            guna2Button6.CustomizableEdges = customizableEdges19;
            guna2Button6.DisabledState.BorderColor = Color.DarkGray;
            guna2Button6.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button6.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button6.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button6.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button6.ForeColor = Color.White;
            guna2Button6.Location = new Point(286, 80);
            guna2Button6.Name = "guna2Button6";
            guna2Button6.ShadowDecoration.CustomizableEdges = customizableEdges20;
            guna2Button6.Size = new Size(225, 56);
            guna2Button6.TabIndex = 15;
            guna2Button6.Text = "Inject (MOD NAME)";
            // 
            // guna2Button7
            // 
            guna2Button7.BorderRadius = 10;
            guna2Button7.CustomizableEdges = customizableEdges17;
            guna2Button7.DisabledState.BorderColor = Color.DarkGray;
            guna2Button7.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button7.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button7.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button7.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button7.ForeColor = Color.White;
            guna2Button7.Location = new Point(286, 142);
            guna2Button7.Name = "guna2Button7";
            guna2Button7.ShadowDecoration.CustomizableEdges = customizableEdges18;
            guna2Button7.Size = new Size(225, 56);
            guna2Button7.TabIndex = 16;
            guna2Button7.Text = "Inject (MOD NAME)";
            // 
            // guna2Button8
            // 
            guna2Button8.BorderRadius = 10;
            guna2Button8.CustomizableEdges = customizableEdges15;
            guna2Button8.DisabledState.BorderColor = Color.DarkGray;
            guna2Button8.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button8.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button8.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button8.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button8.ForeColor = Color.White;
            guna2Button8.Location = new Point(286, 204);
            guna2Button8.Name = "guna2Button8";
            guna2Button8.ShadowDecoration.CustomizableEdges = customizableEdges16;
            guna2Button8.Size = new Size(225, 56);
            guna2Button8.TabIndex = 17;
            guna2Button8.Text = "Inject (MOD NAME)";
            // 
            // guna2Button9
            // 
            guna2Button9.BorderRadius = 10;
            guna2Button9.CustomizableEdges = customizableEdges13;
            guna2Button9.DisabledState.BorderColor = Color.DarkGray;
            guna2Button9.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button9.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button9.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button9.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button9.ForeColor = Color.White;
            guna2Button9.Location = new Point(286, 266);
            guna2Button9.Name = "guna2Button9";
            guna2Button9.ShadowDecoration.CustomizableEdges = customizableEdges14;
            guna2Button9.Size = new Size(225, 56);
            guna2Button9.TabIndex = 18;
            guna2Button9.Text = "Inject (MOD NAME)";
            // 
            // guna2Button10
            // 
            guna2Button10.BorderRadius = 10;
            guna2Button10.CustomizableEdges = customizableEdges11;
            guna2Button10.DisabledState.BorderColor = Color.DarkGray;
            guna2Button10.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button10.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button10.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button10.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button10.ForeColor = Color.White;
            guna2Button10.Location = new Point(286, 328);
            guna2Button10.Name = "guna2Button10";
            guna2Button10.ShadowDecoration.CustomizableEdges = customizableEdges12;
            guna2Button10.Size = new Size(225, 56);
            guna2Button10.TabIndex = 19;
            guna2Button10.Text = "Inject (MOD NAME)";
            // 
            // guna2Button11
            // 
            guna2Button11.BorderRadius = 10;
            guna2Button11.CustomizableEdges = customizableEdges9;
            guna2Button11.DisabledState.BorderColor = Color.DarkGray;
            guna2Button11.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button11.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button11.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button11.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button11.ForeColor = Color.White;
            guna2Button11.Location = new Point(545, 80);
            guna2Button11.Name = "guna2Button11";
            guna2Button11.ShadowDecoration.CustomizableEdges = customizableEdges10;
            guna2Button11.Size = new Size(225, 56);
            guna2Button11.TabIndex = 20;
            guna2Button11.Text = "Inject (MOD NAME)";
            // 
            // guna2Button12
            // 
            guna2Button12.BorderRadius = 10;
            guna2Button12.CustomizableEdges = customizableEdges7;
            guna2Button12.DisabledState.BorderColor = Color.DarkGray;
            guna2Button12.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button12.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button12.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button12.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button12.ForeColor = Color.White;
            guna2Button12.Location = new Point(545, 142);
            guna2Button12.Name = "guna2Button12";
            guna2Button12.ShadowDecoration.CustomizableEdges = customizableEdges8;
            guna2Button12.Size = new Size(225, 56);
            guna2Button12.TabIndex = 21;
            guna2Button12.Text = "Inject (MOD NAME)";
            // 
            // guna2Button13
            // 
            guna2Button13.BorderRadius = 10;
            guna2Button13.CustomizableEdges = customizableEdges5;
            guna2Button13.DisabledState.BorderColor = Color.DarkGray;
            guna2Button13.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button13.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button13.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button13.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button13.ForeColor = Color.White;
            guna2Button13.Location = new Point(545, 204);
            guna2Button13.Name = "guna2Button13";
            guna2Button13.ShadowDecoration.CustomizableEdges = customizableEdges6;
            guna2Button13.Size = new Size(225, 56);
            guna2Button13.TabIndex = 22;
            guna2Button13.Text = "Inject (MOD NAME)";
            // 
            // guna2Button14
            // 
            guna2Button14.BorderRadius = 10;
            guna2Button14.CustomizableEdges = customizableEdges3;
            guna2Button14.DisabledState.BorderColor = Color.DarkGray;
            guna2Button14.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button14.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button14.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button14.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button14.ForeColor = Color.White;
            guna2Button14.Location = new Point(545, 266);
            guna2Button14.Name = "guna2Button14";
            guna2Button14.ShadowDecoration.CustomizableEdges = customizableEdges4;
            guna2Button14.Size = new Size(225, 56);
            guna2Button14.TabIndex = 23;
            guna2Button14.Text = "Inject (MOD NAME)";
            // 
            // guna2Button15
            // 
            guna2Button15.BorderRadius = 10;
            guna2Button15.CustomizableEdges = customizableEdges1;
            guna2Button15.DisabledState.BorderColor = Color.DarkGray;
            guna2Button15.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button15.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button15.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button15.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button15.ForeColor = Color.White;
            guna2Button15.Location = new Point(545, 328);
            guna2Button15.Name = "guna2Button15";
            guna2Button15.ShadowDecoration.CustomizableEdges = customizableEdges2;
            guna2Button15.Size = new Size(225, 56);
            guna2Button15.TabIndex = 24;
            guna2Button15.Text = "Inject (MOD NAME)";
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlDarkDark;
            ClientSize = new Size(782, 403);
            Controls.Add(guna2Button15);
            Controls.Add(guna2Button14);
            Controls.Add(guna2Button13);
            Controls.Add(guna2Button12);
            Controls.Add(guna2Button11);
            Controls.Add(guna2Button10);
            Controls.Add(guna2Button9);
            Controls.Add(guna2Button8);
            Controls.Add(guna2Button7);
            Controls.Add(guna2Button6);
            Controls.Add(guna2Button5);
            Controls.Add(guna2Button4);
            Controls.Add(guna2Button3);
            Controls.Add(guna2Button2);
            Controls.Add(InstallBepinexButton);
            Controls.Add(guna2Panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form2";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form2";
            guna2Panel1.ResumeLayout(false);
            guna2Panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Guna.UI2.WinForms.Guna2AnimateWindow guna2AnimateWindow1;
        private Guna.UI2.WinForms.Guna2BorderlessForm guna2BorderlessForm1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox2;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox3;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox4;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private Guna.UI2.WinForms.Guna2Button InstallBepinexButton;
        private Guna.UI2.WinForms.Guna2Button guna2Button15;
        private Guna.UI2.WinForms.Guna2Button guna2Button14;
        private Guna.UI2.WinForms.Guna2Button guna2Button13;
        private Guna.UI2.WinForms.Guna2Button guna2Button12;
        private Guna.UI2.WinForms.Guna2Button guna2Button11;
        private Guna.UI2.WinForms.Guna2Button guna2Button10;
        private Guna.UI2.WinForms.Guna2Button guna2Button9;
        private Guna.UI2.WinForms.Guna2Button guna2Button8;
        private Guna.UI2.WinForms.Guna2Button guna2Button7;
        private Guna.UI2.WinForms.Guna2Button guna2Button6;
        private Guna.UI2.WinForms.Guna2Button guna2Button5;
        private Guna.UI2.WinForms.Guna2Button guna2Button4;
        private Guna.UI2.WinForms.Guna2Button guna2Button3;
        private Guna.UI2.WinForms.Guna2Button guna2Button2;
        private Guna.UI2.WinForms.Guna2Button BackButton;
    }
}